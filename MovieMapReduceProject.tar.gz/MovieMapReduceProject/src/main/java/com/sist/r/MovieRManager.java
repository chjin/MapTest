package com.sist.r;

import org.rosuda.REngine.Rserve.RConnection;
import org.springframework.stereotype.Component;
@Component
public class MovieRManager {
    public void rGraph()
    {
	   try
	    {
		    RConnection rc=new RConnection();
		    rc.voidEval("data<-read.table(\"/home/sist/javaStudy/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/wtpwebapps/MovieMapReduceProject/output/part-r-00000\")");
	       rc.voidEval("png(\"/home/sist/javaStudy/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/wtpwebapps/MovieMapReduceProject/main/feel.png\",width=900,height=500)"); 
	       rc.voidEval("par(mfrow=c(1,2))");
	       rc.voidEval("pie(data$V2,labels=data$V1,col=rainbow(10))");
	       rc.voidEval("barplot(data$V2,names.arg=data$V1,col=rainbow(10))");
	       rc.voidEval("dev.off()");
	       rc.close();
	    }catch(Exception ex)
	    {
		   System.out.println(ex.getMessage());
	    }
    }
    // 데이터 받기 => 몽고
}





