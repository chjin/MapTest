package com.sist.movie;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sist.data.MovieDTO;
import com.sist.data.MovieManager;
import com.sist.mapred.MovieDriver;
import com.sist.r.MovieRManager;

import java.io.File;
import java.util.*;
@Controller
public class MovieController {
	 @Autowired
    private MovieManager mgr;
	 @Autowired
	 private MovieDriver md;
	 @Autowired
	 private MovieRManager mr;
	 @RequestMapping("main/list.do")
	 public String movie_list(Model model)
	 {
		 List<MovieDTO> list=mgr.movieAllData();
		 List<String> raList=mgr.movieRank();
		 List<String> reList=mgr.movieReserve();
		 List<String> bList=mgr.movieBoxoffice();
		 model.addAttribute("list", list);
		 model.addAttribute("raList", raList);
		 model.addAttribute("reList", reList);
		 model.addAttribute("bList", bList);
		 return "main/list";
	 }
	 @RequestMapping("main/detail.do")
	 public String main_detail(int no,Model model)
	 throws Exception
	 {
		 File file = new File("/home/sist/javaStudy/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/wtpwebapps/MovieMapReduceProject/desc.txt");
		 if(file.exists())
			   file.delete();
		 
		 file = new File("/home/sist/javaStudy/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/wtpwebapps/MovieMapReduceProject/desc.txt");
		 file.createNewFile();
		 
		 MovieDTO vo=mgr.movieDetail(no);
		 // 댓글 수집 
		 for(int i=1;i<=3;i++)
		 {
			 String json=
					 mgr.review_data(vo.getTitle(), i);
			 mgr.jsonParse(json);
		 }
		 // MapReduce(Hadoop) => part-r-00000
		 md.movieMapReduce();
		 // Rserve => part-r-00000 (Graph)
		 mr.rGraph();
		 // Rserve => Data받기 
		 //  필요한 데이터를 MongoDB에 저장 (추천) 
		 model.addAttribute("vo", vo);
		 return "main/detail";
	 }
}











